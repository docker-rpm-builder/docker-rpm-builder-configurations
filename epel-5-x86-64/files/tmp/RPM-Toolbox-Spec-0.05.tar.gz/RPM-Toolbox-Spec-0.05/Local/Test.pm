# vim:ts=2:sts=2:sw=2:et

package Local::Test;
use warnings;
use strict;
use Cwd;
use File::Path qw(rmtree);
use File::Spec::Functions;
use Test::More;
use Test::Builder;
use RPM::Toolbox::Spec;

our $WORKDIR = catfile (getcwd, "tmp");
rmtree $WORKDIR;
mkdir $WORKDIR or die "$WORKDIR: $!\n";

my $Test = Test::Builder->new;

sub find_rpm() {
  my $version_string = `LC_ALL=C LANG= rpm --version 2>/dev/null`;
  $? == 0 or return undef;
  $version_string =~ / (\d\S+)\s*$/o or return undef;
  my $version = $1;
  return $version;
}

sub rpm_plan {
  my $rpmver = find_rpm;
  unless ($rpmver) {
    plan skip_all => "rpm not found";
    return
  };
  plan @_;
  return $rpmver;
}

# Parse a spec given as a string with default options
sub rpm_parse_string ($;%) {
  local $_;
  my ($text, %opts) = @_;
  my @dflt_defines = (
    "_topdir $WORKDIR",
  );
  if ($opts{defines}) {
    unshift @{$opts{defines}}, @dflt_defines;
  } else {
    $opts{defines} = [ @dflt_defines ];
  };
  $opts{workdir} or $opts{workdir} = $WORKDIR;
  return RPM::Toolbox::Spec->parse_string (
    $text, %opts);
};

# Make sure a scalar is in the list
sub in_list($$;$) {
  my ($x, $list, $name) = @_;
  local $_;
  for (@{$list}) {
    $x eq $_ and do {
      $Test->ok (1, $name);
      return;
    };
  };
  $Test->ok (0, $name);
  $Test->diag (qq(     '$x' is not in list:));
  $Test->diag ($Test->explain ($list));
}

# Make sure a scalar is in the list
sub not_in_list($$;$) {
  my ($x, $list, $name) = @_;
  local $_;
  for (@{$list}) {
    $x eq $_ and do {
      $Test->ok (0, $name);
      $Test->diag (qq(     '$x' is in list, unexpectedly:));
      $Test->diag ($Test->explain ($list));
      return;
    };
  };
  $Test->ok (1, $name);
}

BEGIN {
  use Exporter ();
  our @ISA = qw(Exporter);
  our @EXPORT_OK = qw($WORKDIR find_rpm rpm_plan rpm_parse_string
                      in_list not_in_list);
  our %EXPORT_TAGS = (all => [@EXPORT_OK])
}

1;


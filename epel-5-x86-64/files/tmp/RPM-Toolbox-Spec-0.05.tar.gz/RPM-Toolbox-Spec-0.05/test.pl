#!/usr/bin/perl
# vim:ts=2:sts=2:sw=2:et

use 5.008;
use warnings;
use strict;
use Test::Harness;
use lib "lib";

my @rpmdirs = (
  [ "DEFAULT" ],
  [ "4.3"     => "/opt/rpm/rpm-4.3"     ],
  [ "4.4.2"   => "/opt/rpm/rpm-4.4.2"   ],
  [ "4.4.2.3" => "/opt/rpm/rpm-4.4.2.3" ],
  [ "4.6.1"   => "/opt/rpm/rpm-4.6.1"   ],
  [ "4.7.2"   => "/opt/rpm/rpm-4.7.2"   ],
  [ "4.8.1"   => "/opt/rpm/rpm-4.8.1"   ],
  [ "5.0.3"   => "/opt/rpm/rpm-5.0.3"   ],
  [ "5.1.9"   => "/opt/rpm/rpm-5.1.9"   ],
  [ "5.2.1"   => "/opt/rpm/rpm-5.2.1"   ],
  [ "5.3.1"   => "/opt/rpm/rpm-5.3.1"   ],
);

sub load_extra_mods() {
  my @modlist = qw(TAP::Harness TAP::Parser TAP::Formatter::Console);
  my @failed;
  for (@modlist) {
    eval "use $_";
    $@ and push @failed, $_;
  };
  if (@failed) {
    warn "WARNING: recommended modules not found: @failed\n";
    return undef;
  };
  return 1;
}

sub find_prog($) {
  my $prog = shift;
  for (split (/:+/o, $ENV{PATH})) {
    -x "$_/$prog" and return "$_/$prog";
  };
  return undef;
}

sub rpm_version($) {
  my $prog = shift;
  $prog or return '';
  my $ver = `$prog --version 2>/dev/null`;
  $? == 0 or return '';
  $ver =~ / ([0-9.]+)\s*$/o or return '';
  return $1;
}

sub create_test_sets($$$) {
  my ($harness, $aggregator, $testlist) = @_;
  my @runlist;
  my $want_ver = $ENV{TEST_RPMVER} || 'DEFAULT';
  for my $rec (@rpmdirs) {
    my $key = $rec->[0];
    my $dir = $rec->[1];
    if ($want_ver ne 'ALL' and $want_ver ne $key) {
      next;
    };
    my ($path_prefix, $ldpath_prefix);
    my $testname_prefix;
    if ($key eq 'DEFAULT') {
      $path_prefix = "";
      $ldpath_prefix = "";
      $testname_prefix = "";
    } else {
      next unless -x "$dir/bin/rpm" && -x "$dir/bin/rpmbuild";
      $path_prefix = "$dir/bin:";
      $ldpath_prefix = "$dir/lib:";
      $testname_prefix = "[RPM $key] ";
    };
    my $run = sub {
      local $ENV{PATH} = $path_prefix . $ENV{PATH};
      local $ENV{LD_LIBRARY_PATH} = $ldpath_prefix . $ENV{LD_LIBRARY_PATH};
      $harness->aggregate_tests ($aggregator,
        map { [ $_, "$testname_prefix$_" ] } @{$testlist});
    };
    push @runlist, $run;
  };
  return @runlist;
}

if (load_extra_mods) {
  my $aggregator = TAP::Parser::Aggregator->new;
  my $formatter = TAP::Formatter::Console->new ({
    verbosity => $ENV{TEST_VERBOSE},
    color => 1,
    jobs => 1,
  });
  my $harness = TAP::Harness->new ({
    formatter => $formatter,
    lib => "lib",
  });
  my @runlist = create_test_sets ($harness, $aggregator, [ glob ("t/rpm/*.t") ]);
  $aggregator->start;
  $harness->aggregate_tests ($aggregator, glob ("t/*.t"));
  for (@runlist) {
    &{$_};
  };
  $aggregator->stop;
  $formatter->summary ($aggregator);
} else {
  runtests (glob ("t/*.t"), glob ("t/rpm/*.t"));
}


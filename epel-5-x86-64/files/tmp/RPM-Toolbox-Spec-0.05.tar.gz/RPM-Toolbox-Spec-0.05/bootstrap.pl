#!/usr/bin/perl
# vim:ts=2:sts=2:sw=2:et

use 5.008;
use warnings;
use strict;
use lib "lib";
use version 0.77;
use Getopt::Long qw(:config gnu_getopt no_auto_abbrev no_ignore_case);
use File::Basename;
use Cwd;
use IO::File;
use File::Find;
use YAML qw(LoadFile DumpFile);

my $PROGNAME             = basename ($0);
my $MAIN_PACKAGE         = "RPM::Toolbox::Spec";
my $DISTNAME             = "RPM-Toolbox-Spec";
my $LICENSE              = "perl";
my $MAIN_PACKAGE_FILE    = "lib/RPM/Toolbox/Spec.pm";
my $MAIN_PACKAGE_POD     = "lib/RPM/Toolbox/Spec.pod";
my $PRIVATE_DIR          = "Local";
my @REQ_FILES            = "lib";
my @BUILDREQ_FILES       = (qw(t test.pl Local), @REQ_FILES);
my @CONFIGREQ_FILES      = qw(Makefile.PL.in);
my $REQ_BASENAME_PATTERN = qr/\.(pm|pl|PL|t)(\.in)?$/;
my %REQ;
my %BUILDREQ;
my %CONFIGREQ;
my $ABSTRACT;
my $AUTHOR;
my $DISTVERSION;
my $ACTION;

# Save a module version dependency
sub merge_version($$$) {
  my ($modhash, $mod, $newver_str) = @_;
  my $oldver_str = $modhash->{$mod};
  defined ($newver_str) or $newver_str = "0";
  defined ($oldver_str) or $oldver_str = "0";
  my $newver = version->parse ($newver_str);
  my $oldver = version->parse ($oldver_str);
  my $ver_str = $newver > $oldver ? $newver_str : $oldver_str;
  $modhash->{$mod} = $ver_str;
};

# Extract module dpendencies from a file
sub get_file_deps($$) {
  my ($filename, $modhash) = @_;
  warn "  $_\n";
  local $_;
  my $fh = IO::File->new ($filename, 'r') or die "$filename: $!\n";
  while (defined ($_ = $fh->getline)) {
    /^\s*(use|require)\b(\s+([a-zA-Z][a-zA-Z0-9:]+))?(\s+([0-9.]+))?/o and do {
      my ($mod, $ver_str) = ($3, $5);
      defined ($mod) or $mod = "perl"; 
      $mod =~ /^(warnings|strict|lib)$/o and next;
      $mod =~ /^Local\b/o and next;
      $mod =~ /^\Q$MAIN_PACKAGE\E\b/o and next;
      merge_version ($modhash, $mod, $ver_str);
    };
  };
  $fh->close or die "$filename: $!\n";
}

# Find config, build and runtime dependencies
sub find_deps() {
  local $_;
  my $do_find = sub {
    my ($modhash, $fplist) = @_;
    my @flist = grep { defined and -e $_ } map { glob $_ } @{$fplist};
    find (
      {
        wanted => sub { -f and $_ =~ $REQ_BASENAME_PATTERN and get_file_deps ($_, $modhash) },
        no_chdir => 1,
      },
      @flist
    );
  };
  warn "looking for configure dependencies:\n";
  &{$do_find} (\%CONFIGREQ, \@CONFIGREQ_FILES);
  warn "looking for build dependencies\n";
  &{$do_find} (\%BUILDREQ, \@BUILDREQ_FILES);
  warn "looking for runtime dependencies\n";
  &{$do_find} (\%REQ, \@REQ_FILES);
}

# Extract NAME and AUTHOR from main package's POD
sub parse_pod() {
  my $fh = IO::File->new ($MAIN_PACKAGE_POD, 'r') or die "$MAIN_PACKAGE_POD: $!\n";
LINE:
  while (defined ($_ = $fh->getline)) {
RETRY:
    /^=head1\s+NAME/o and do {
      while (defined ($_ = $fh->getline)) {
        /^\Q$MAIN_PACKAGE\E\s+-\s+(.*)$/o and do {
          $ABSTRACT = $1;
          $ABSTRACT =~ s/\s+$//go;
          next LINE;
        };
        /^\s*$/ and next;
        defined $_ or last LINE;
        goto RETRY;
      };
      next;
    };
    /^=head1\s+AUTHOR/o and do {
      while (defined ($_ = $fh->getline)) {
        /^\s*$/o and next;
        /^=/ and goto RETRY;
        $AUTHOR = $_;
        $AUTHOR =~ s/^\s+//go;
        $AUTHOR =~ s/\s+$//go;
        $AUTHOR =~ s/E<lt>/</go;
        $AUTHOR =~ s/E<gt>/>/go;
        last;
      };
      next;
    };
  }
  $fh->close or die "$MAIN_PACKAGE_POD: $!\n";
  $ABSTRACT or die "$MAIN_PACKAGE_POD: couldn't find NAME\n";
  $AUTHOR or die "$MAIN_PACKAGE_POD: couldn't find AUTHOR\n";
}

# Generate META.yml
sub make_meta() {
  warn "generating META.yml\n";
  my $in = IO::File->new ("META.yml.in", 'r') or die "META.yml.in: $!\n";
  my $out = IO::File->new ("META.yml", 'w') or die "META.yml: $!\n";
  while (defined ($_ = $in->getline)) {
    s/\@GENERATOR\@/$PROGNAME/go;
    s/\@DISTNAME\@/$DISTNAME/go;
    s/\@DISTVERSION\@/$DISTVERSION/go;
    s/\@ABSTRACT\@/$ABSTRACT/go;
    s/\@AUTHOR\@/$AUTHOR/go;
    s/\@LICENSE\@/$LICENSE/go;
    s/\@MAIN_PACKAGE\@/$MAIN_PACKAGE/go;
    s/\@MAIN_PACKAGE_FILE\@/$MAIN_PACKAGE_FILE/go;
    s/\@MAIN_PACKAGE_VERSION\@/$DISTVERSION/go;
    s/\@PRIVATE_DIR\@/$PRIVATE_DIR/go;
    /^(\s+)\@(CONFIGREQ|BUILDREQ|REQ)\@/o and do {
      $_ = '';
      my $modhash;
      if ($2 eq 'CONFIGREQ') {
        $modhash = \%CONFIGREQ;
      } elsif ($2 eq 'BUILDREQ') {
        $modhash = \%BUILDREQ;
      } else {
        $modhash = \%REQ;
      };
      for my $mod (sort (keys (%$modhash))) {
        $out->print ($1, $mod, ": ", $modhash->{$mod}, "\n");
      };
    };
    $out->print ($_);
  };
  $out->close or die "META.yml: $!\n";
  $in->close or die "META.yml.in: $!\n";
}

# Generate Makefile.PL
sub make_makefile_pl() {
  warn "generating Makefile.PL\n";
  my $in = IO::File->new ("Makefile.PL.in", 'r') or die "Makefile.PL.in: $!\n";
  my $out = IO::File->new ("Makefile.PL", 'w') or die "Makefile.PL: $!\n";
  while (defined ($_ = $in->getline)) {
    s/\@GENERATOR\@/$PROGNAME/go;
    s/\@DISTNAME\@/$DISTNAME/go;
    s/\@DISTVERSION\@/$DISTVERSION/go;
    s/\@ABSTRACT\@/$ABSTRACT/go;
    s/\@AUTHOR\@/$AUTHOR/go;
    s/\@LICENSE\@/$LICENSE/go;
    s/\@MAIN_PACKAGE\@/$MAIN_PACKAGE/go;
    s/\@MAIN_PACKAGE_FILE\@/$MAIN_PACKAGE_FILE/go;
    s/\@MAIN_PACKAGE_VERSION\@/$DISTVERSION/go;
    s/\@PRIVATE_DIR\@/$PRIVATE_DIR/go;
    $out->print ($_);
  };
  $out->close or die "Makefile.PL: $!\n";
  $in->close or die "Makefile.PL.in: $!\n";
};

# Generate configreq.list buildreq.list and req.list
sub make_rpm_spec() {
  my $meta = YAML::LoadFile ("META.yml");
  my (@rpm_buildreq, @rpm_req);
  my $add_req = sub {
    my ($reqlist, $mod, $ver) = @_;
    my $req = $mod eq 'perl' ? 'perl' : "perl($mod)";
    $ver and $req .= " >= $ver";
    push @$reqlist, $req;
  };
  for (sort (keys (%{$meta->{configure_requires}}))) {
    &$add_req (\@rpm_buildreq, $_, $meta->{configure_requires}->{$_});
  };
  for (sort (keys (%{$meta->{build_requires}}))) {
    &$add_req (\@rpm_buildreq, $_, $meta->{build_requires}->{$_});
  };
  for (sort (keys (%{$meta->{requires}}))) {
    &$add_req (\@rpm_req, $_, $meta->{requires}->{$_});
  };
  my $outfile = "perl-RPM-Toolbox-Spec.spec";
  my $infile = "$outfile.in";
  warn "generating $outfile\n";
  my $in = IO::File->new ($infile, 'r') or die "$infile: $!\n";
  my $out = IO::File->new ($outfile, 'w') or die "$outfile: $!\n";
  while (defined ($_ = $in->getline)) {
    /^\@RPM_BUILD_REQUIRES\@\s*$/o and do {
      for my $dep (@rpm_buildreq) {
        $out->print ("BuildRequires: ", $dep, "\n");
      };
      next;
    };
    /^\@RPM_REQUIRES\@\s*$/o and do {
      for my $dep (@rpm_req) {
        $out->print ("Requires: ", $dep, "\n");
      };
      next;
    };
    s/\@VERSION\@/$DISTVERSION/go;
    $out->print ($_);
  };
  $out->close or die "$outfile: $!\n";
  $in->close or die "$infile: $!\n";
}

# Generate files required for distribution
sub target_bootstrap() {
  eval "use $MAIN_PACKAGE";
  $@ and die $@;
  $DISTVERSION = eval "\$${MAIN_PACKAGE}::VERSION";
  parse_pod;
  find_deps;
  make_meta;
  make_makefile_pl;
  make_rpm_spec;
}

# Remove all generated files
sub target_clean() {
  my $pbase = $MAIN_PACKAGE;
  $pbase =~ s/::/-/go;
  my $cleanfiles = <<_END
META.yml
Makefile.PL
perl-$pbase.spec
$pbase-*.tar.gz
Makefile
tmp
blib
pm_to_blib
_END
  ;
  my $cmd = "rm -rf " . join (' ', split (/\s+/o, $cleanfiles));
  warn "$cmd\n";
  system ($cmd);
  $? == 0 or exit 1;
}

# build a release
sub target_dist() {
  target_bootstrap;
  my $cmd = "perl Makefile.PL && make dist";
  warn "$cmd\n";
  system ($cmd);
  $? == 0 or exit 1;
}

# Build RPM packages
sub target_rpm() {
  target_dist;
  my $cwd = getcwd;
  my $cmd = "rpmbuild --define \"_sourcedir $cwd\" -ba perl-RPM-Toolbox-Spec.spec";
  warn "$cmd\n";
  system $cmd;
  $? == 0 or exit 1;
}

# Print a help message and exit
sub help() {
  print <<_END
Usage: $PROGNAME [OPTIONS] TARGET
Generate module build scripts.
 -h,--help        print out a help message and exit

Targets:
  bootstrap (default)
  dist
  rpm
  clean

_END
  ;
  exit 0;
}

# Process command line
sub init() {
  my $target;
  GetOptions (
    'h|help' => \&help,
  );
  if ($#ARGV >= 0) {
    $#ARGV > 0 and die "extra arguments on command line\n";
    $target = shift (@ARGV);
    $target =~ /^(bootstrap|dist|rpm|clean)$/o
      or die "invalid target \"$target\"\n";
    $target = "target_$target";
  } else {
    $target = "target_bootstrap";
  };
  return $target;
}

my $target = init;
eval $target;
$@ and die $@;

